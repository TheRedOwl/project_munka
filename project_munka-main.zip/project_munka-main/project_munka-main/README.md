# project_munka
 
 ## képek és ikonok forrása
 - pexels: https://www.pexels.com/hu-hu/
 - pixabay: https://pixabay.com/hu/
 - lorem picsum: https://picsum.photos/
 - freepik: https://www.freepik.com/
 - flaticon: https://www.flaticon.com/
:tada:
